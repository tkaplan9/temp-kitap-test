import React, { Component } from 'react';

import {
	Text, View, TextInput, Button, Alert
} from 'react-native';
import {Actions, Scene, Router} from 'react-native-router-flux';

import {
	setSessionTicket
} from '../../common/index';

export default class LoginPage extends Component {

	constructor(props) {
		super(props);

		this.state = {			
			userName: "",
			userPassword: ""
		};
	}

	goLogin() {
		const { userName }  = this.state ;
 		const { userPassword }  = this.state ;

		if ( userName == "" || userPassword == "" ) {
			Alert.alert("Boş bırakamazsınız");
		} 
		else {
			fetch('http://10.0.2.2:8080/user_login.php', {
				method: "POST",
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					name: userName,
					password: userPassword
				})
			})
			.then((res) => res.json()) //text
			.then((res) => {
				//console.log(res)
				if (res.session_ticket)
					setSessionTicket(String(res.session_ticket));
				if (res.result == 1)
					Actions.MainPage({type: 'reset'});
				else if (res.result == -1 )
					Alert.alert("Kullanıcı doğrulanamadı");
				else if (res.result == -2 )
					Alert.alert("Yanlış şifre");
			})
			.catch((err) => {
				Alert.alert("LG " + err);
			})
		}
	}

	render() {
		return(
			<View
				style={{
					flex: 1,
					justifyContent: 'center',
					alignItems: 'center'}}>
				<View style={{ width: 300}}>
					<TextInput
						value={this.state.userName}
						onChangeText={(value) => this.setState({userName: value})}
						placeholder="Kullanıcı adı"/>
				</View>
				<View style={{ width: 300}}>
					<TextInput
						onChangeText={(value) => this.setState({userPassword: value})}
						value={this.state.userPassword}
						placeholder="Şifre"/>
				</View>
				<View style={{ width: 100}}>
					<Button
					  	title="Giriş"
					  	color="#00f" 
					  	onPress={this.goLogin.bind(this)} />
				</View>
				<View
					style={{top: 150}}>
					<Text>Hesabınız Yok Mu?</Text>
					<Button
					  	title="Kayıt ol"
					  	color="#00f" 
					  	onPress={()=>{
							Actions.SignUpPage({type: 'reset'});}}/>
				</View>
			</View>
		);
	}
} 