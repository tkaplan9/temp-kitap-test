import React, { Component } from 'react';

import {
	Text, View, TextInput, Button, Alert
} from 'react-native';
import {Actions, Scene, Router} from 'react-native-router-flux';

import {
	setSessionTicket
} from '../../common/index';

export default class SignUpPage extends Component {

	constructor(props) {
		super(props);

		this.state = {			
			userName: "",
			userEmail: "",
			userPassword: ""
		};
	}

	signUp() {
		const { userName }  = this.state ;
 		const { userEmail }  = this.state ;
 		const { userPassword }  = this.state ;

		if ( userEmail == "" || userName == "" || userPassword == "" ) {
			Alert.alert("Boş bırakamazsınız");
		} 
		else {
			fetch('http://10.0.2.2:8080/user_registration.php', {
				method: "POST",
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					name: userName,
					email: userEmail,
					password: userPassword
				})
			})
			.then((res) => res.json())
			.then((res) => {
				if (res.session_ticket)
					setSessionTicket(String(res.session_ticket));
				if (res.result == 1)
					Actions.MainPage({type: 'reset'});
				else if (res.result == -1 )
					Alert.alert("Kullanıcı doğrulanamadı");
				else if (res.result == -2 )
					Alert.alert("Bu E-mail başka bir hesap tarafından kullanılıyor");
				else if (res.result == -3 )
					Alert.alert("Bu kullanıcı adı uygun değil");
			})
			.catch((err) => {
				Alert.alert("SU " + err);
			})
		}
	}

	render() {
		return(
			<View
				style={{
					flex: 1,
					justifyContent: 'center',
					alignItems: 'center'}}>
				<View>
					<TextInput
						style={{ width: 300}}
						onChangeText={(value) => this.setState({userEmail: value})}
						value={this.state.userEmail}
						placeholder="E-mail"/>
				</View>
				<View>
					<TextInput
						style={{ width: 300}}
						value={this.state.userName}
						onChangeText={(value) => this.setState({userName: value})}
						placeholder="Kullanıcı adı"/>
				</View>
				<View>
					<TextInput
						style={{ width: 300}}
						onChangeText={(value) => this.setState({userPassword: value})}
						value={this.state.userPassword}
						placeholder="Şifre"/>
				</View>
				<View
					style={{ width: 100 }}>
					<Button
					  	title="Kaydol"
					  	color="#0000ff" 
					  	onPress={this.signUp.bind(this)} />
				</View>
				<View
					style={{top: 150}}>
					<Button
					  	title="Geri Dön"
					  	color="grey" 
					  	onPress={()=>{
							Actions.LoginPage({type: 'reset'});}}/>
				</View>
			</View>
		);
	}
} 