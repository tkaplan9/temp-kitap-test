import React, { Component } from 'react';
import {Actions, Scene, Router} from 'react-native-router-flux';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, AsyncStorage} from 'react-native';
import ScrollableTabView, {DefaultTabBar, ScrollableTabBar} from 'react-native-scrollable-tab-view';

import TabBarIcons from './TabBarIcons';

async function logOut() {
	await AsyncStorage.removeItem("session_ticket"); 
	Actions.StartPage({type: 'reset'})
}

export default class MainPage extends Component {
	constructor(props) {
		super(props);
	}

	render() {
		return(
		<ScrollableTabView
		style={{marginTop: 10}}
		initialPage={1}
		renderTabBar={() => <TabBarIcons/>}
		>
			<ScrollView tabLabel="ios-paper" style={styles.tabView}>
			  <View style={styles.card}>
				<Text>News</Text>
			  </View>
			</ScrollView>
			<ScrollView tabLabel="ios-people" style={styles.tabView}>
			  <View style={styles.card}>
				<Text>Friends</Text>
			  </View>
			</ScrollView>
			<ScrollView tabLabel="ios-chatboxes" style={styles.tabView}>
			  <View style={styles.card}>
				<Text>Messenger</Text>
			  </View>
			</ScrollView>
			<ScrollView tabLabel="ios-notifications" style={styles.tabView}>
			  <View style={styles.card}>
				<Text>Notifications</Text>
			  </View>
			</ScrollView>
			<ScrollView tabLabel="ios-settings" style={styles.tabView}>
			  <View style={styles.card}>			
				<TouchableOpacity style={{ 
				padding: 10, backgroundColor: 'grey'}} 
				onPress = {()=>logOut()}>
					<Text>Log Out</Text>
				</TouchableOpacity>
			  </View>
			</ScrollView>
		</ScrollableTabView>
			
		);
	}
}

const styles = StyleSheet.create({
	tabView: {
		flex: 1,
		padding: 10,
		backgroundColor: 'rgba(0,0,0,0.01)',
	  },
	  card: {
		borderWidth: 1,
		backgroundColor: '#fff',
		borderColor: 'rgba(0,0,0,0.1)',
		margin: 5,
		height: 150,
		padding: 15,
		shadowColor: '#ccc',
		shadowOffset: { width: 2, height: 2, },
		shadowOpacity: 0.5,
		shadowRadius: 3,
	  },
	});

	/*
	
	*/	
