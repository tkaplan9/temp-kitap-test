import React, { Component } from 'react';
import {Actions, Scene, Router} from 'react-native-router-flux';
import {
	Text,
	Button,
	View,
	ActivityIndicator
} from 'react-native';

import {
	isLogin
} from '../../common/index';

export default class StartPage extends Component {
	
	constructor(props) {
		super(props);

		this.isLoginControl();
	}

	async isLoginControl() {
		isLogin().then((res) => {
			if (res)
				Actions.MainPage({type: 'reset'}); // reset geçmişi temizler 
			else 
				Actions.LoginPage({type: 'reset'});
		})
	}

	render() {
		return(
			<View
				style={{
					flex: 1,
					alignItems: 'center',
					justifyContent: 'center'
				}}>
				<ActivityIndicator size = "large" />
				<View style = {{top: 25}}>
					<Text style = {{fontSize: 20}}>Yükleniyor</Text>
				</View>
			</View>
		);
	}
} 