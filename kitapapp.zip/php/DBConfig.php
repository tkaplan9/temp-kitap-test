<?php
 
//db host
//$HostName = "localhost";
$HostName = "46.4.76.92";

//db name
//$DatabaseName = "idkman";
$DatabaseName = "KiBakUserDb";

//db username
//$HostUser = "root";
$HostUser = "KeysDbAdmin";

//db password
//$HostPass = "r";
$HostPass = "1qazXSW2Psswrd1234*";

//host port (mysql, not apache, no need if 3306 - default )
$portNum = "49004";
 
?>