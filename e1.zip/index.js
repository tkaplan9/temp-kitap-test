import React, { Component } from 'react';
import {
	AppRegistry
} from 'react-native';
import {name as appName} from './app.json';

import {Actions, Scene, Router} from 'react-native-router-flux';
import LoginPage from './src/pages/login-page/login-page';
import MainPage from './src/pages/main-page/main-page';
import StartPage from './src/pages/start-page/start-page';
import SignUpPage from './src/pages/signup-page/signup-page';

export default class App extends Component {
	
	render() {
		const scenes = Actions.create(
			<Scene key="root" hideNavBar="true">
		    	<Scene key="StartPage" component={StartPage}/>
		    	<Scene key="LoginPage" component={LoginPage}/>
				<Scene key="SignUpPage" component={SignUpPage}/>
		    	<Scene key="MainPage" component={MainPage}/>
			</Scene>
		);

		return <Router scenes={scenes}/>
	}
}

AppRegistry.registerComponent(appName, () => App);