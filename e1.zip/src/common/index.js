import AsyncStorage from '@react-native-community/async-storage';

export async function isLogin() {
	var session = await AsyncStorage.getItem("session_ticket");
	if (session != null)
		return true;
	return false;
}

export async function setSessionTicket(ticket) { // giriş yapınca gelen değeri kayıt ediyoruz
	AsyncStorage.setItem("session_ticket", ticket);
}